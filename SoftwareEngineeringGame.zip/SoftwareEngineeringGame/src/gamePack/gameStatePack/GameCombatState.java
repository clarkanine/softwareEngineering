package gamePack.gameStatePack;

public interface GameCombatState extends GameState {
	void combat();	
}
