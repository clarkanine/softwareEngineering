package gamePack.gameStatePack;

public interface GameInitialState extends GameState {
	public void gameBuild();
	void gameRun();

}
