package gamePack.gameStatePack;

public interface GameFinalState extends GameState {
	void gameSave();
	void gameShutdown();

}
