package gamePack.gameEntityPack.gameArtifactPack;

import gamePack.gameEntityPack.GameEntity;

public interface GameArtifact extends GameEntity {
	
}
