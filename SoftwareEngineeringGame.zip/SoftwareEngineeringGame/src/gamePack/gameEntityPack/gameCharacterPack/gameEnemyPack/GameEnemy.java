package gamePack.gameEntityPack.gameCharacterPack.gameEnemyPack;

import gamePack.gameEntityPack.GameEntity;

public interface GameEnemy extends GameEntity {
	public double getDifficulty();
}
