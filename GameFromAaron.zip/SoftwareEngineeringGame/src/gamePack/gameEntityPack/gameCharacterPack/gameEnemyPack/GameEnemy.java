package gamePack.gameEntityPack.gameCharacterPack.gameEnemyPack;

import gamePack.gameEntityPack.gameCharacterPack.GameCharacter;

public interface GameEnemy extends GameCharacter
{
	public int getDifficulty();
}
