package characterPack;

public interface Health
{
	public void setHealth(int health);
	public int getHealth();
	public int getMaxHealth();
	public void setMaxHealth(int maxHealth);
}
