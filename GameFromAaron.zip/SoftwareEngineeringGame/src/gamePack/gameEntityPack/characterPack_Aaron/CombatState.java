package characterPack;


public interface CombatState
{
	public void run();
	public String getName();
}
