package characterPack;

public interface Attack
{
	public void attack(ConcreteCharacter me, ConcreteCharacter you);
}
