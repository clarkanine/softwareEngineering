package characterPack;

public interface Dead
{
	public void setDead(boolean dead);
	public boolean isDead();
	public void checkDead();
}
