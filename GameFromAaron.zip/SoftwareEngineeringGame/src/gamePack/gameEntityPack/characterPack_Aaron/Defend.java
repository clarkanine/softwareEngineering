package characterPack;

public interface Defend
{
	public void defend(ConcreteCharacter me);
}
