package characterPack;

public interface State
{
	public void run();
}
